# SWE102_SP21_SE1432_Team4

Assignment 2 :

1.         Study Configuration Tools (Github).
2.         Create new account Git
3.         Check-in/Check-out : Java Desktop project to Github
